-- ============================================================
-- Atelier Manager — Mise à jour du schéma (à exécuter après le 1er script)
-- Ajoute les colonnes nécessaires pour les ventes et dépenses
-- ============================================================

alter table ventes add column if not exists produit_nom text;
alter table ventes add column if not exists prix_unitaire numeric(12,2);

alter table depenses add column if not exists categorie text default 'Autre';
